/*
* Program prints "Hello World"
* @author Emily Hsu
* @author Natasha Kho
* Version 0.0.0
* Created 8/25/2025
* Last modified 8/25/2025, 7:13 PM PST
*/

#include <iostream> 

using namespace std;

int main() {
    // displays a hello world message
    cout << "Hello, world!" << endl;
    return 0;
}